./PSSMHCpan test/test.fa 9 HLA-A0101 database/Human_HLAPeptides_20151222/PSSM/pssm_file.list
./PSSMHCpan test/test.fa 9 HLA-A0102 database/Human_HLAPeptides_20151222/PSSM/pssm_file.list

